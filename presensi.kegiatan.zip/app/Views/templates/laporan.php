<html>

<head>
   <title>Rekap absen <?= $grup ?></title>
   <style>
      body {
         font-family: Arial, Helvetica, sans-serif;
      }

      table {
         border-collapse: collapse;
      }
   </style>
</head>


<body>

   <?= $this->renderSection('content') ?>

</body>

</html>