<!-- CSS Files -->
<link href="<?= base_url('assets/fonts/fonts.css?v=1.0.0'); ?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/material-dashboard.css'); ?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/style.css?v=1.0.0'); ?>" rel="stylesheet" />
<link rel="stylesheet" href="<?= base_url('assets/js/plugins/file-uploader/css/jquery.dm-uploader.min.css'); ?>" />
<link rel="stylesheet" href="<?= base_url('assets/js/plugins/file-uploader/css/styles-1.0.css'); ?>" />

<link rel="apple-touch-icon" sizes="76x76" href="<?= base_url('assets/img/apple-icon.png'); ?>">
<link rel="icon" type="image/png" href="<?= base_url('assets/img/favicon.png'); ?>">